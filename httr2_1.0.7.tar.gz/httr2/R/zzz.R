.onLoad <- function(...) {
  cache_disk_prune()
}
