# unknown header triggers error

    Code
      parse_aws_event(bytes)
    Condition
      Error in `type_enum()`:
      ! Unsupported type 255.
      i This is an internal error that was detected in the httr2 package.
        Please report it at <https://github.com/r-lib/httr2/issues> with a reprex (<https://tidyverse.org/help/>) and the full backtrace.

